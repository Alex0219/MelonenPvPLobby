package de.fileinputstream.lobby.commands;

public class CommandGiveall {
}
