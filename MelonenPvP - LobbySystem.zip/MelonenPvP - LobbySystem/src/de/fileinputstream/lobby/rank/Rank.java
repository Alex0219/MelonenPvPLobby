package de.fileinputstream.lobby.rank;

public enum Rank {


}
